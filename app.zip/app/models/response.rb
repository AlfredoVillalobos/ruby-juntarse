class Response < ApplicationRecord
  belongs_to :invitation
end
