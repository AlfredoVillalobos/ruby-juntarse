class Disponibility < ApplicationRecord
  belongs_to :user
end
